// MessageSender.java (partial implementation)
import java.util.*;
/**
 * This class implements the sender side of the data link layer.
 * <P>
 * The source code supplied here contains only a partial implementation.
 * Your completed version must be submitted for assessment.
 * <P>
 * You only need to finish the implementation of the sendMessage
 * method to complete this class.  No other parts of this file need to
 * be changed.  Do NOT alter the constructor or interface of any public
 * method.  You may add new private methods, if you wish, but do NOT
 * create any new classes.  Only this file will be processed when your
 * work is marked.
 */

public class MessageSender
{
    // Fields ----------------------------------------------------------

    private FrameSender physicalLayer;   // physical layer object
    private boolean quiet;              // true=quiet mode (suppress
    // prompts and status info)

    // You may add additional fields but this shouldn't be necessary

    // Constructor -----------------------------------------------------

    /**
     * MessageSender constructor (DO NOT ALTER ANY PART OF THIS)
     * Create and initialize new MessageSender.
     * @param physicalLayer physical layer object with frame sender service
     * (this will already have been created and initialized by TestSender)
     * @param quiet true for quiet mode which suppresses prompts and status info
     */

    public MessageSender(FrameSender physicalLayer, boolean quiet)
    {
        // Initialize fields and report status

        this.physicalLayer = physicalLayer;
        this.quiet = quiet;
        if (!quiet) {
            System.out.println("Data link layer ready");
        }
    }

    // Methods ---------------------------------------------------------

    /**
     * Send a message (THIS IS THE ONLY METHOD YOU NEED TO MODIFY)
     * @param message the message to be sent.  The message can be any
     * length and may be empty but the string reference should not
     * be null.
     * @throws ProtocolException immediately without attempting to
     * send any further frames if (and only if) the physical layer
     * throws an exception or the given message can't be sent
     * without breaking the rules of the protocol (e.g. if the MTU
     * is too small)
     */

    public void sendMessage(String message) throws ProtocolException
    {
        // Announce action
        // (Not required by protocol but helps when debugging)  
        int checkSum = 000;
        int resultingSpace = physicalLayer.getMTU()-8;
        ArrayList <String> frames = new ArrayList<String>();
        ArrayList <String> checkSums = new ArrayList<String>();
        String lastFrame = ".";
        String newFrame = ("(" + message + ":" + checkSum + ":" + "." + ")");

        if (!quiet) {
            int total = 0;

            // Split string into lengths
            // store into arraylist 1
            if (message == ""){
                checkSum = 0;
            }
            else {
                if(message.length()>resultingSpace)
                {
                    int start  = 0;
                    int end = resultingSpace + start;
                    while(message.length()>resultingSpace)
                    {
                        //remove required length
                        String messageSub = message.substring(start, end);
                        start = end;
                        end = end + resultingSpace;

                        //store first part into arraylist
                        frames.add(messageSub);
                        //loop through rest of message
                    }
                }

                //Calculate checksum for each frame
                //loop through frame & grab each message

                for(int i = 0;i<frames.size();i++)
                {
                    String frameSum = frames.get(i);
                    for(int j=0; j<message.length(); j++){

                        char c = message.charAt(i);
                        Character.getNumericValue(c);
                        total = c + total;
                        checkSum = total;

                    }
                    checkSums.add(Integer.toString(checkSum));
                }
                //store into arraylist 2

                //

                //send message
                //Find duplicate colon
                CharSequence searchColon = ":"; 
                if(message.contains(searchColon)) {
                    message = message.replace(":","::");
                }

                //paddding of checksum to needed length
                for(int i = 0;i<checkSums.size();i++)
                {
                    String sum = checkSums.get(i);
                    if(sum>100 && sum<999)
                    {sum = Integer.toString(sum);}
                    if(sum=0)
                    {sum = "000";}
                    if(sum>0 && sum<10)
                    {sum = "00" + sum;}
                    if(sum>=10 && sum<100)
                    {sum = "0" + sum;}
                    
                }
                if (checkSum > 999){
                    //iterates through position of checkSum value
                    while(checkSum < 0) {
                        int digit = checkSum % 10; 
                        pos = 0;
                        if (pos > 3){
                            sum += digit;
                        }
                        checkSum /= 10;
                        pos++;
                        //int firstDigit = Integer.parseInt(Integer.toString(checkSum).substring(0, 1));;

                        //String numberString = "" + checkSum;
                        //char firstLetterChar = numberString.charAt(0);
                        //int firstDigit = Integer.parseInt("" + firstLetterChar);

                        //checkSum = firstDigit.replace(firstLetterChar,"");     //firstDigit = 0;

                        //Padded Checksum
                        String checkSumString = "" + checkSum;
                        char result = checkSumString.charAt(0);
                        for(int h=0; h<checkSumString.charAt(h);h++)
                        {
                            int firstInt = Character.getNumericValue(checkSumString.charAt(0));
                            //Integer.parseInt(checkSumString);
                            int newCS = checkSum - (firstInt * 1000);
                            System.out.println("(" + message + ":" + "0" + newCS + ":" + "." + ")");
                            //checkSum = newCS;
                        }
                        //System.out.println("(" + message + ":" + checkSum + ":" + "." + ")");	

                        //for(int j = 0; j < strLength; ++j) {
                        //String spaceHolder = "000";
                        //String intString = String.valueOf(checkSum1);
                        //String string = spaceHolder.substring(intString.length()).contact(intString);
                        //return checkSum;

                        //Colin's to be deleted

                    }
                }	

                else if (checkSum < 100){
                    int firstDigit = Integer.parseInt(Integer.toString(checkSum).substring(0, 1));;
                    String.format("%03d", firstDigit);
                    System.out.println("(" + message + ":" + "0" + firstDigit + ":" + "." + ")");
                }	

            }
        }
        frames.add(newFrame);
    }    

    for(int l = 0; l < frames.size(); l++) {
        System.out.println((frames.get(l).toString()));
    }  
    //what is intended is to create a loop where it itterates through adding each figure and then   
    //using the charAt method converting this to a numberical number

    // The following statement shows how the frame sender is invoked.
    // At the moment it just passes the whole message directly to
    // the physical layer.  That is, of course, wrong!

    if(frames.size()== -1){
        //physicalLayer.sendFrame(message);
    }
    physicalLayer.sendFrame(message);

    // sendMessage should split large messages into several smaller
    // segments.  Each segment must be encoded as a frame in the
    // format specified.  sendFrame will need to be called separately
    // for each frame in turn.  See the coursework specification
    // and other class documentation for further info.

    // message.replace #4
    // System.out.println("length of string = " + str.length());
    //{if()
    //Here we need to seperate segments of the message recieved imto segments,
    //where they are split into

}
// end of method sendMessage
}
}
// You may add private methods if you wish
// end of class MessageSender
