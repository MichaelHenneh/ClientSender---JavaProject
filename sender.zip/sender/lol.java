// MessageSender.java (partial implementation)
import java.util.*;
import java.text.*;
 
/**
 * This class implements the sender side of the data link layer.
 * <P>
 * The source code supplied here contains only a partial implementation.
 * Your completed version must be submitted for assessment.
 * <P>
 * You only need to finish the implementation of the sendMessage
 * method to complete this class.  No other parts of this file need to
 * be changed.  Do NOT alter the constructor or interface of any public
 * method.  You may add new private methods, if you wish, but do NOT
 * create any new classes.  Only this file will be processed when your
 * work is marked.
 */
 
//public class MessageSender
{
    // Fields ----------------------------------------------------------
 
    private FrameSender physicalLayer;   // physical layer object
    private boolean quiet;               // true=quiet mode (suppress
    // prompts and status info)
 
    // You may add additional fields but this shouldn't be necessary
 
    // Constructor -----------------------------------------------------
 
    /**
     * MessageSender constructor (DO NOT ALTER ANY PART OF THIS)
     * Create and initialize new MessageSender.
     * @param physicalLayer physical layer object with frame sender service
     * (this will already have been created and initialized by TestSender)
     * @param quiet true for quiet mode which suppresses prompts and status info
     */
 
    public MessageSender(FrameSender physicalLayer, boolean quiet)
    {
        // Initialize fields and report status
 
        this.physicalLayer = physicalLayer;
        this.quiet = quiet;
 
        if (!quiet) {
            System.out.println("Data link layer ready");
        }
    }
 
    // Methods ---------------------------------------------------------
 
    /**
     * Send a message (THIS IS THE ONLY METHOD YOU NEED TO MODIFY)
     * @param message the message to be sent.  The message can be any
     * length and may be empty but the string reference should not
     * be null.
     * @throws ProtocolException immediately without attempting to
     * send any further frames if (and only if) the physical layer
     * throws an exception or the given message can't be sent
     * without breaking the rules of the protocol (e.g. if the MTU
     * is too small)
     */
 
    public void sendMessage(String message) throws ProtocolException
    {
        // Announce action
        // (Not required by protocol but helps when debugging)
        if(!quiet)
        {
            System.out.println("Sending message => " + message);
        }
         
        //if(physicalLayer.getMTU() )
         
         
 
        int checkSum = 0;
        String checkSumFormatted = "";
        String isLastFrame = "+";
        int frameSpaceLeft = physicalLayer.getMTU() - 8;
        ArrayList<String> messageArray = new ArrayList<String>();
        int begin, end;
        String frame = "";
 
        //check if message is bigger then frame length. If bigger split into required length
        if(message.length()>frameSpaceLeft)
        {
            for(int i = 0;i<message.length();)
            {
                frame = "";
                for(int j = 0; (j<frameSpaceLeft) && (i<message.length()); j++)
                {
                    char ch = message.charAt(i);
                    if(ch == ':')
                    {
                        j++;
                        if(j<frameSpaceLeft)
                        {
                            frame = frame + ch;
                            i++;
                        }
                    }
                    else
                    {
                        frame = frame + ch;
                        i++;
                    }
                }
                //frame = frame.replaceAll(":","::");
                messageArray.add(frame);
 
            }
        }
        else
        {
            frame = message;
            //frame = frame.replaceAll(":","::");
            messageArray.add(frame);
        }
 
        for(int i = 0; i<messageArray.size(); i++)
        {
            frame = messageArray.get(i);
            //calculate checksum value for the message.
            if (frame.equals(""))
            {
                checkSum = 0;
            }
            else
            {
                int temp = 0;
                for(int j = 0; j< frame.length(); j++)
                {
                    temp = temp + frame.charAt(j);
                }
                checkSum = temp;
            }
 
            //format checksum to 3 digit decimal
            if(checkSum>999)
            {
                //Reduce value to last three digits
                while(checkSum>999)
                {
                    checkSumFormatted = Integer.toString(checkSum);
                    checkSumFormatted = checkSumFormatted.substring(1);
                    checkSum = Integer. valueOf(checkSumFormatted);
                }
            }
 
            //Padding
            //Pad checkSum with appropriate number of zeros
            if(checkSum>100 && checkSum<999)
            {checkSumFormatted = Integer.toString(checkSum);}
            //Pad checkSum with appropriate number of zeros
            if(checkSum==0)
            {checkSumFormatted = "000";}
            //Pad checkSum with appropriate number of zeros
            if(checkSum>0 && checkSum<10)
            {checkSumFormatted = "00" + checkSum;}
            //Pad checkSum with appropriate number of zeros
            if(checkSum>=10 && checkSum<100)
            {checkSumFormatted = "0" + checkSum;}
 
            //parse message string to check for ":" values  and expand
            frame = frame.replaceAll(":","::");
            //if message string is empty send frame without message
             
            if(i == (messageArray.size()-1))
            {
                isLastFrame = ".";
            }
             
             
            if(frame.equals(""))
            {physicalLayer.sendFrame("(" + ":" + checkSumFormatted + ":" + isLastFrame + ")");}
            //else send with message
            else
            {physicalLayer.sendFrame("(" + frame + ":" + checkSumFormatted + ":" + isLastFrame + ")");}
        }
 
        // The following statement shows how the frame sender is invoked.
        // At the moment it just passes the whole message directly to
        // the physical layer.  That is, of course, wrong!
 
        // sendMessage should split large messages into several smaller
        // segments.  Each segment must be encoded as a frame in the
        // format specified.  sendFrame will need to be called separately
        // for each frame in turn.  See the coursework specification
        // and other class documentation for further info.
 
    } // end of method sendMessage
 
    // You may add private methods if you wish
 
} // end of class MessageSender